<?php
// Redirigir automáticamente a la página de administración de hospitales
header("Location: admin_hospitales.php");
exit();
?>
